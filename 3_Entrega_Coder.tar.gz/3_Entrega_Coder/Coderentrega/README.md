# Proyecto Django - Sistema de Inscripción

## Instalación

1. Clona el repositorio:
   ```bash
   git clone <URL>
   cd <nombre-del-proyecto>
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
